<ul class="nav" id="side-menu">
    <li>
        <a href="account.php"><i class="fa fa-dashboard fa-fw"></i> 後台管理者帳號管理</a>
    </li>
    <li>
        <a href="#"><i class="fa fa-sitemap fa-fw"></i> 網站資訊管理<span class="fa arrow"></span></a>
        <ul class="nav nav-second-level">
            <li>
                <a href="webinfo.php">網站資訊管理</a>
            </li>
            <li>
                <a href="copyrightInfo.php">版權資訊管理</a>
            </li>
            <li>
                <a href="webSeo.php">網頁最佳化管理</a>
            </li>
        </ul>
        <!-- /.nav-second-level -->
    </li>
    <li>
        <a href="setSlider.php"><i class="fa fa-dashboard fa-fw"></i> 首頁大圖輪播管理</a>
    </li>
    <li>
        <a href="sidead.php"><i class="fa fa-dashboard fa-fw"></i> 側邊廣告管理</a>
    </li>

    <li>
        <a href="article.php"><i class="fa fa-dashboard fa-fw"></i> 各館管理</a>
    </li>
    <li>
        <a href="aboutus.php"><i class="fa fa-dashboard fa-fw"></i> 關於我們單元管理</a>
    </li>
    <li>
        <a href="setnews.php"><i class="fa fa-dashboard fa-fw"></i> 最新消息管理</a>
    </li>
    <li>
        <a href="#"><i class="fa fa-sitemap fa-fw"></i> 常見問答管理<span class="fa arrow"></span></a>
        <ul class="nav nav-second-level">
            <li>
                <a href="qandaclass.php">常見問答類別管理</a>
            </li>
            <li>
                <a href="qanda.php">常見問答內容管理</a>
            </li>
        </ul>
        <!-- /.nav-second-level -->
    </li>
    <li>
        <a href="#"><i class="fa fa-sitemap fa-fw"></i> 檔案下載管理<span class="fa arrow"></span></a>
        <ul class="nav nav-second-level">
            <li>
                <a href="downloadclass.php">檔案下載類別管理</a>
            </li>
            <li>
                <a href="dlfile.php">檔案下載內容管理</a>
            </li>
        </ul>
        <!-- /.nav-second-level -->
    </li>
    <li>
        <a href="contactus.php"><i class="fa fa-dashboard fa-fw"></i> 聯絡我們管理</a>
    </li>
    <li>
        <a href="advisory.php"><i class="fa fa-dashboard fa-fw"></i> 預約諮詢管理</a>
    </li>
</ul>